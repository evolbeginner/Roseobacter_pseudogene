#!/usr/bin/perl


#################################################
use File::Basename;

$DIR = dirname($0);

$Psi_Fi_module2 = $DIR . '/' . 'Psi_Phi_module2.pl';



#################################################
system "ls *.sortie.out > list.file";
open FILE, "<", "list.file";
while(<FILE>)
{
	chomp;
	if(/^(\S+)\.vs\.(\S+)\.sortie\.out$/)
	{
		$query=$1;
		$target=$2;
		open SCRIPT, ">", "$query\.vs\.$target\.module2.in";
		print SCRIPT "$query\.vs\.$target\.sortie.out\n";
		print SCRIPT "$target\.gbk\n";
		print SCRIPT "pseudo_$target\_use_$query\n";
		print SCRIPT "$target\.fas\n";
		print SCRIPT "Y\n";
		close SCRIPT;
		open IN, ">", "$query\.vs\.$target\.module2.fmi";
		print IN "perl $Psi_Fi_module2 $query\.vs\.$target\.temp < $query\.vs\.$target\.module2.in";
		close IN;
		system "chmod 755 $query\.vs\.$target\.module2.fmi";
		#system "./$query\.vs\.$target\.module2.fmi";
	}
}
close FILE;
system "rm list.file";

