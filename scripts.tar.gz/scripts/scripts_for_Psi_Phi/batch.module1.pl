#!/usr/bin/perl

############################################
use File::Basename;


############################################
$DIR = dirname($0);

$Psi_Fi_module1 = "$DIR" . '/' . "Psi_Phi_module1.pl";



############################################
system "ls *.blast > list.file";
open FILE, "<", "list.file";
while(<FILE>)
{
	chomp;
	if(/^(\S+)\.vs\.(\S+)\.blast$/)
	{
		$query=$1;
		$target=$2;
		open SCRIPT, ">", "$query\.vs\.$target\.module1.in";
		print SCRIPT "$query\.vs\.$target\.blast\n";
		print SCRIPT "$target\n";
		print SCRIPT "$query\.gbk\n";
		print SCRIPT "$query\.vs\.$target\.sortie.out\n";
		print SCRIPT "Y\n";
		close SCRIPT;
		open IN, ">", "$query\.vs\.$target\.module1.fmi";
		print IN "perl $Psi_Fi_module1 < $query\.vs\.$target\.module1.in";
		close IN;
		print "chmod 755 $query\.vs\.$target\.module1.fmi \n";
		print "./$query\.vs\.$target\.module1.fmi \n";
		system "chmod 755 $query\.vs\.$target\.module1.fmi";
		system "./$query\.vs\.$target\.module1.fmi";
	}
}
close FILE;
system "rm list.file";

