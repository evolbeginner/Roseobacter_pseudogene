#! /usr/bin/env ruby


######################################################
require 'getoptlong'
require 'bio'
require 'getoptlong'

require_relative 'check_pseudogene_aln'
require 'util'
require 'Dir'


######################################################
infile = nil
genome_dir = nil
prot_dir = nil
check_indir = nil
check_sub_indirs = Array.new
problematic_query_list_file = nil
cpu = 1
outdir = nil
is_force = false
targets = Array.new
is_strict = false

out_fhs = Hash.new
problematic_queries = Array.new


######################################################
def getMaxOrfLen(seq)
  max_len = 0
  aa = ''

  seq.upcase.scan(/.../) do |codon|
    case codon
      when 'ATG', 'CTG', 'TTG'
        aa << 'B'
      when 'TAA', 'TAG', 'TGA'
        aa << 'E'
      else
        aa << 'O'
    end
  end

  max_len = aa.scan(/B[^E]+/).map{|i|i.size}.max

  max_len = 0 if max_len.nil?

  if aa =~ /^[^E]+/ and $&.size > max_len
    max_len = $&.size
  end

  return(max_len)
end


######################################################
opts = GetoptLong.new(
  ['-i', GetoptLong::REQUIRED_ARGUMENT],
  ['-p', '--prot', GetoptLong::REQUIRED_ARGUMENT],
  ['-g', '--genome', GetoptLong::REQUIRED_ARGUMENT],
  ['--check_indir', GetoptLong::REQUIRED_ARGUMENT],
  ['--problematic_query', '--problematic_query_list', GetoptLong::REQUIRED_ARGUMENT],
  ['--target', GetoptLong::REQUIRED_ARGUMENT],
  ['--strict', GetoptLong::NO_ARGUMENT],
  ['--cpu', GetoptLong::REQUIRED_ARGUMENT],
  ['--outdir', GetoptLong::REQUIRED_ARGUMENT],
  ['--force', GetoptLong::NO_ARGUMENT],
)


opts.each do |opt, value|
  case opt
    when '-i'
      infile = value
    when '-p', '--prot'
      prot_dir = value
    when '-g', '--genome'
      genome_dir = value
    when '--check_indir'
      check_indir = value
    when '--problematic_query', '--problematic_query_list'
      problematic_query_list_file = value
    when '--target'
      targets = value.split(',')
    when '--strict'
      is_strict = true
    when '--cpu'
      cpu = value.to_i
    when '--outdir'
      outdir = value
    when '--force'
      is_force = true
  end
end


######################################################
check_sub_indirs = read_infiles(check_indir)

problematic_queries = read_list(problematic_query_list_file) unless problematic_query_list_file.nil?

mkdir_with_force(outdir, is_force)


######################################################
protfiles = read_infiles(prot_dir, 'faa')
species2seqObjs = read_seq_dir(protfiles, cpu)

species2pseudo = read_pseudogene_file(infile, targets)

genome_seqObjs = read_genome(genome_dir, targets)

out_fhs[:desc] = File.open(File.join(outdir, 'desc.tbl'), 'w')
out_fhs[:short_query] = File.open(File.join(outdir, 'short_query.list'), 'w')
out_fhs[:long_query] = File.open(File.join(outdir, 'long_query.list'), 'w')
out_fhs[:query_no_1] = File.open(File.join(outdir, 'query_no_1.list'), 'w')
out_fhs[:orf_cov_80] = File.open(File.join(outdir, 'orf_cov_80.list'), 'w')


######################################################
species2pseudo.each_pair do |species, v1|
  puts species
  Parallel.map(v1, in_process:cpu) do |pseudogene, pseudo|
    #MSLA0044|MSLA0044_00361
    gene = pseudo.genes[0]
    taxon = gene.split('|')[0]
    genome = genome_seqObjs[species].seq
    prot_seq = species2seqObjs[taxon][gene].seq
    is_problematic_query = false

    nucl = get_seq_from_genome(genome, pseudo.start, pseudo.stop, pseudo.strand)
    max_orf_len = getMaxOrfLen(nucl)
    #puts [pseudo.name, max_orf_len, prot_seq.size, (max_orf_len/prot_seq.size.to_f).round(2)].join("\t")
    if is_strict
      if not problematic_queries.empty? and pseudo.genes.all?{|i|problematic_queries.include?(i)}
        is_problematic_query = true
      end
    else
      if not problematic_queries.empty? and pseudo.genes.any?{|i|problematic_queries.include?(i)}
        is_problematic_query = true
      end
    end

    orf_cov = max_orf_len/(prot_seq.size.to_f).round(2)

    out_fhs[:desc].puts [pseudo.name, 
      pseudo.type,
      prot_seq.size, 
      orf_cov, 
      pseudo.genes.size,
      is_problematic_query
      ].join("\t")

    if prot_seq.size < 100
      out_fhs[:short_query].puts pseudo.name
    end
    if orf_cov >= 0.8
      out_fhs[:orf_cov_80].puts pseudo.name
    end
    if pseudo.genes.size == 1
      out_fhs[:query_no_1].puts pseudo.name
    end
    if is_problematic_query
      out_fhs[:long_query].puts pseudo.name
    end
  end
end


######################################################
out_fhs.values.map{|i|i.close}


