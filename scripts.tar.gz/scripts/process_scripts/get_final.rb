#! /usr/bin/env ruby


#####################################################
require 'getoptlong'
require_relative 'check_pseudogene_aln'


#####################################################
infile = nil
targets = Array.new
include_list_files = Array.new

genes_included = Hash.new


#####################################################
opts = GetoptLong.new(
  ['-i', GetoptLong::REQUIRED_ARGUMENT],
  ['--target', GetoptLong::REQUIRED_ARGUMENT],
  ['--include_list', GetoptLong::REQUIRED_ARGUMENT],
)


opts.each do |opt, value|
  case opt
    when '-i'
      infile = value
    when '--target'
      targets = value.split(',')
    when '--include_list'
      include_list_files << value.split(','); include_list_files.flatten!
  end
end


#####################################################
include_list_files.each do |file|
  genes_included.merge!(read_list(file))
end

species2pseudo = read_pseudogene_file(infile, targets)


puts %W[genome start end strand query_gene_locus Evalue shared_synteny_block overlapped_ORF Psi_Phi_category].join("\t")
species2pseudo.each_pair do |species, v1|
  v1.each_pair do |pseudogene, pseudo|
    next if genes_included.include?(pseudo.name)
    puts pseudo.lines.join("\n")
  end
end


