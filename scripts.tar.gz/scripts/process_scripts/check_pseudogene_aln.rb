#! /usr/bin/env ruby


#######################################
require 'getoptlong'
require 'parallel'
require 'bio'

require 'SSW_bio'
require 'util'
require 'Dir'


#######################################
infile = nil
prot_dir = nil
genome_dir = nil
targets = Array.new
cpu = 1
outdir = nil
is_force = false
is_tolerate = false


#######################################
class Bio::Sequence::NA
  def strict_complement
    seq.tr('ATGCUatgcu','TACGAtacga')
  end
end


class Bio::FastaFormat
  attr_accessor :revseq
  #def revseq
  #  return(strict_complement(Bio::Sequence.auto(seq)))
  #end
end


class Pseudo
  attr_accessor :genes, :start, :stop, :strand, :name, :type, :lines
  def initialize(line_arr)
    @start, @stop = line_arr[1, 2].map{|i|i.to_i}
    @strand = line_arr[3]
    @genes = line_arr[4].split(', ')
    @name = line_arr[0]
    @type = line_arr[7].nil? ? 'intergenic' : 'cds'
    @lines = [line_arr.join("\t")]
  end

  def next_line(line)
    @lines << line
  end
end


#######################################
def read_pseudogene_file(infile, targets)
  species2pseudo = Hash.new{|h1,k1|h1[k1]={}}

  in_fh = File.open(infile, 'r')
  in_fh.each_line do |line|
#Ruegeria_atlantica_HKCCD8344_ps1	1409301	1411631	+	Ruegeria_jwlk_MSLA0235A|MSLA0235A_00908, Ruegeria_jwlk_MSLA0235A|MSLA0235A_00907		.		
    next if line =~ /^genome/
    next if line =~ /^\t/
    line.chomp!
    line_arr = line.split("\t")
    pseudogene = line_arr[0]
    pseudogene =~ /^(.+) _[^_]+$/x; species = $1

    next if not targets.include?(species) unless targets.empty?
    species2pseudo[species][pseudogene] = Pseudo.new(line_arr)
    species2pseudo[species][pseudogene].next_line(in_fh.readline)
  end
  in_fh.close

  return(species2pseudo)
end


def read_seq_dir(protfiles, cpu=1)
  seqObjs = Hash.new
  res = Parallel.map(protfiles, in_processes: cpu) do |protfile|
    h = Hash.new
    in_fh = Bio::FlatFile.open(protfile)
    in_fh.each_entry do |f|
      title = f.definition.split(' ')[0]#.split('|')[-1]
      h[title] = f
    end
    in_fh.close
    [getCorename(protfile), h]
  end
  res.map{|c,h|seqObjs[c]=h}
  return(seqObjs)
end


def read_genome(genome_dir, targets)
  h = Hash.new
  #genome_files = targets.map{|i|File.join(genome_dir, i+'.fas')}
  genome_files = read_infiles(genome_dir, 'fas')
  genome_files.each do |genome_file|
    c = getCorename(genome_file)
    next unless targets.include?(c) unless targets.empty?
    in_fh = Bio::FlatFile.open(genome_file)
    in_fh.each_entry do |f|
      seq_obj = Bio::Sequence.auto(f.seq)
      #f.revseq = seq_obj.strict_complement
      h[c] = f
    end
    in_fh.close
  end
  return(h)
end


def output(species2pseudo, genome_seqObjs, species2seqObjs, outdir, cpu)
  species2pseudo.each_pair do |species, v1|
    puts species
    sub_outdir = File.join(outdir, species)

    Parallel.map(v1, in_process:cpu) do |pseudogene, pseudo|
      pseudo_outdir = File.join(sub_outdir, pseudogene)
      mkdir_with_force(pseudo_outdir)
      #prot_outdir = File.join(pseudo_outdir, 'prot')
      #mkdir_with_force(prot_outdir)
      tblastn_outfile = File.join(pseudo_outdir, 'tblastn.blast')
      tblastn_outfile6 = File.join(pseudo_outdir, 'tblastn.blast6')

      genome = genome_seqObjs[species].seq
      begin
        seq = get_seq_from_genome(genome, pseudo.start, pseudo.stop, pseudo.strand)
      rescue
        p [tblastn_outfile6, genome[pseudo.start], genome[pseudo.stop], pseudo.strand]
      end
      nucl_file = File.join(pseudo_outdir, 'nucl.fas')
      out_fh = File.open(nucl_file, 'w')
      out_fh.puts ['>'+pseudo.name, seq].join("\n")
      out_fh.close

      prot_outfile = File.join(pseudo_outdir, 'prot.fas')
      out_fh = File.open(prot_outfile, 'w')
      prot_seq = nil
      pseudo.genes.each do |gene|
        taxon = gene.split('|')[0]
        #p species2seqObjs[taxon][gene].seq; p '!'; exit
        if not species2seqObjs.include?(taxon)
          p species2seqObjs[taxon]
          exit
        end
        next if not species2seqObjs[taxon].include?(gene)
        out_fh.puts ['>'+gene, species2seqObjs[taxon][gene].seq].join("\n")
        prot_seq = species2seqObjs[taxon][gene].seq if prot_seq.nil?
      end
      out_fh.close

      `tblastn -query #{prot_outfile} -subject #{nucl_file} -outfmt 0 > #{tblastn_outfile}`
      `tblastn -query #{prot_outfile} -subject #{nucl_file} -outfmt 6 > #{tblastn_outfile6}`

      extend_nucl(tblastn_outfile6, prot_outfile, prot_seq, genome, pseudo, pseudo_outdir)
    end
  end
end


def get_seq_from_genome(genome, start, stop, strand)
  #p [genome[start-1], genome[stop-1], start, stop, strand]
  seq = Bio::Sequence.auto(genome[start-1, stop-start+1])
  seq = strand == '-' ? seq.reverse_complement : seq.to_s
  return(seq)
end


def extend_nucl(tblastn_outfile6, prot_outfile, prot_seq, genome, pseudo, pseudo_outdir)
  in_fh = File.open(tblastn_outfile6, 'r')
  return if File.zero?(tblastn_outfile6)
  line = in_fh.readline
  in_fh.close

  q_start, q_stop = line.split("\t").values_at(6, 7).map{|i|i.to_i}
  q_start_diff = (q_start - 1) * 3
  q_stop_diff = (prot_seq.size - q_stop) * 3
  if pseudo.strand == '+'
    start = pseudo.start - q_start_diff
    stop = pseudo.stop + q_stop_diff
  else
    start = pseudo.start - q_stop_diff
    stop = pseudo.stop + q_start_diff
  end
  seq = get_seq_from_genome(genome, start, stop, pseudo.strand)

  nucl_file = File.join(pseudo_outdir, 'extended_nucl.fas')
  tblastn_outfile = File.join(pseudo_outdir, 'extended_tblastn.blast')
  tblastn_outfile6 = File.join(pseudo_outdir, 'extended_tblastn.blast6')
  out_fh = File.open(nucl_file, 'w')
  out_fh.puts ['>'+pseudo.name, seq].join("\n")
  out_fh.close
  `tblastn -query #{prot_outfile} -subject #{nucl_file} -outfmt 0 > #{tblastn_outfile}`
  `tblastn -query #{prot_outfile} -subject #{nucl_file} -outfmt 6 > #{tblastn_outfile6}`
end


#######################################
#######################################
if __FILE__ == $0
  opts = GetoptLong.new(
    ['-i', GetoptLong::REQUIRED_ARGUMENT],
    ['-p', '--prot', GetoptLong::REQUIRED_ARGUMENT],
    ['-g', '--genome', GetoptLong::REQUIRED_ARGUMENT],
    ['--target', GetoptLong::REQUIRED_ARGUMENT],
    ['--cpu', GetoptLong::REQUIRED_ARGUMENT],
    ['--outdir', GetoptLong::REQUIRED_ARGUMENT],
    ['--force', GetoptLong::NO_ARGUMENT],
    ['--tolerate', GetoptLong::NO_ARGUMENT],
  )


  opts.each do |opt, value|
    case opt
      when '-i'
        infile = value
      when '-p', '--prot'
        prot_dir = value
      when '-g', '--genome'
        genome_dir = value
      when '--target'
        targets = value.split(',')
      when '--cpu'
        cpu = value.to_i
      when '--outdir'
        outdir = value
      when '--force'
        is_force = true
      when '--tolerate'
        is_tolerate = true
    end
  end


  #######################################
  mkdir_with_force(outdir, is_force, is_tolerate)


 #######################################
  protfiles = read_infiles(prot_dir, 'faa')

  species2seqObjs = read_seq_dir(protfiles, cpu)

  species2pseudo = read_pseudogene_file(infile, targets)

  genome_seqObjs = read_genome(genome_dir, targets)

  output(species2pseudo, genome_seqObjs, species2seqObjs, outdir, cpu)

end


