# SSW bio


#####################################################################################
require 'bio'


#####################################################################################
def read_seq_file(seq_file)
  seq_objs = Hash.new
  Bio::FlatFile.open(seq_file).each_entry do |f|
    seq_objs[f.definition] = f
  end
  return seq_objs
end


def read_alns_into_2D_hash(infiles)
  seq_objs = Hash.new{|h,k|h[k]={}}
  infiles.each_with_index do |infile, index|
    bio_in_fh = Bio::FlatFile.open(infile)
    bio_in_fh.each_entry do |f| 
      seq_objs[f.definition][index] = f 
    end 
    bio_in_fh.close
  end 
  return(seq_objs)
end


def read_alns_into_aln_info(infiles)
  aln_info = Hash.new{|h,k|h[k]=[]}
  infiles.each_with_index do |infile, index|
    bio_in_fh = Bio::FlatFile.open(infile)
    bio_in_fh.each_entry do |f| 
      aln_info[index] << f
    end 
    bio_in_fh.close
  end 
  return(aln_info)
end


def get_aln_length(seq_file)
  require 'bio'
  lengths = Array.new
  Bio::FlatFile.open(seq_file).each_entry do |f|
    lengths << f.seq.size
  end

  if lengths.all?{|length|length == lengths[0]}
    return(lengths[0])
  else
    return(false)
  end
end


def getGenomeSize(seq_objs)
  return(seq_objs.values.map{|f|f.length}.reduce(:+))
end



############################################################
#BLAST
class BlastHit
  attr_accessor :query, :subject, :iden, :len, :mismatch, :gap, :qstart, :qend, :sstart, :send, :evalue, :bitscore
  def initialize(line)
    line.chomp!
    line_arr = line.split("\t")
    @query, @subject = line_arr[0,2]
    @iden, @evalue, @bitscore = line_arr.values_at(2,10,11).map{|i|i.to_f}
    @len, @mismatch, @gap, @qstart, @qend, @sstart, @send = line_arr[3,7].map{|i|i.to_i}
  end
end


def getBlastHitObjs(blast_file)
  blastHitObjs = Hash.new{|h1,k1|h1[k1]=Hash.new{|h2,k2|h2[k2]=[]}}
  in_fh = File.open(blast_file, 'r')
  in_fh.each_line do |line|
    line.chomp!
    blastHit = BlastHit.new(line)
    query, subject = blastHit.query, blastHit.subject
    blastHitObjs[query][subject] << blastHit
  end
  in_fh.close

  blastHitObjs.each_pair do |query, v1|
    v1.each_pair do |subject, blastHits|
      blastHitObjs[query][subject] = blastHits.sort_by{|i|i.bitscore}.reverse
    end
  end

  return(blastHitObjs)  
end


def getTaxaFromPhylip(infile)
  in_fh = File.open(infile, 'r')
  lines = in_fh.readlines
  lines.shift
  taxa = lines.map{|line|line.split(/\s+/)[0]}
  in_fh.close
  return(taxa)
end


def guessSeqType(infile)
  in_fh = Bio::FlatFile.open(infile)
  f = in_fh.entries[0]
  in_fh.close
  s = Bio::Sequence.auto(f.seq)
  return(s.seq.class)
end


