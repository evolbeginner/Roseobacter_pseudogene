#! /bin/env ruby


##########################################
DIR = File.dirname($0)
$: << File.join(DIR, 'lib')


##########################################
require 'getoptlong'

require 'util'
require 'Dir'
require 'Hash'


##########################################
indir = nil
outdir = nil
is_force = false
dist = 0


##########################################
def parse_pseudo_file(infile, outdir)
  in_fh = File.open(infile, 'r')
  c = getCorename(infile)
  #c =~ /([^_]+)_use/
  c =~ /pseudo_(.+)_use/
  chr = $1
  outfile = File.join(outdir, chr+'.bed')
  out_fh = File.open(outfile, 'a')
  in_fh.each_line do |line|
    #MSLA0370_00049	2.29e-18	-	1302951	1303061						intergenic
    #MSLA0370_00007	1.80e-106	+	4418975	4419478	4419044	4419481		hypothetical protein	MSLA0235A_04319	bad annotation: short sequence in target genome and in match	0.646017699115044
    line.chomp!
    next if line =~ /probably not/
    line_arr = line.split("\t")
    query, evalue, strand, blast_start, blast_stop, gene_start, gene_stop, unknown, annot, overlap, type, prop = line_arr
    out_fh.puts [chr, blast_start, blast_stop, query, overlap, strand].join("\t")
  end
  in_fh.close
  out_fh.close
end


def merge_gene_based_on_clstr(clstr_outdir, syl_outdir)
  Dir[clstr_outdir+'/*'].each do |clstr_file|
    clstrs = multi_D_Hash(2)
    c = getCorename(clstr_file)
    in_fh = File.open(clstr_file, 'r')
    in_fh.each_line do |line|
      #GNM1573	1	681	MSLA0235A_00001 .	+	1
      line.chomp!
      chr, start, stop, query, overlap, strand, clstr = line.split("\t")
      pseudo_gene = chr+'_'+'ps'+clstr
      clstrs[pseudo_gene][:start] = start
      clstrs[pseudo_gene][:stop] = stop
      clstrs[pseudo_gene][:strand] = strand
      clstrs[pseudo_gene][:overlap] = overlap
      #clstrs[pseudo_gene][:type] = type
      # queries
      ! clstrs[pseudo_gene].include?(:queries) and clstrs[pseudo_gene][:queries] = []
      clstrs[pseudo_gene][:queries] << query
    end

    outfile = File.join(syl_outdir, c+'.txt')
    out_fh = File.open(outfile, 'w')
    clstrs.each do |pseudo_gene, v|
      #genome	start	end	strand	query_gene_locus	Evalue	shared_synteny_block	overlapped_ORF	Psi_Phi_category
      #HKCCA0037_ps00001	77761	79185	+	HKCCA5794_04010, HKCCD7217_03894, HKCCA6259_04177, 	0.0		HKCCA0037_00075, 
      out_fh.puts [pseudo_gene, v[:start], v[:stop], v[:strand], v[:queries].join(', '), v[:evalue], '.', v[:overlap], v[:type]].join("\t")
      out_fh.puts "\t"
    end
    out_fh.close
  end
  `cat #{syl_outdir}/* > #{syl_outdir}/../all_pseudo.txt`
end


##########################################
opts = GetoptLong.new(
  ['--indir', GetoptLong::REQUIRED_ARGUMENT],
  ['--outdir', GetoptLong::REQUIRED_ARGUMENT],
  ['--force', GetoptLong::NO_ARGUMENT],
  ['-d', GetoptLong::REQUIRED_ARGUMENT],
)

opts.each do |opt, value|
  case opt
    when '--indir'
      indir = value
    when '--outdir'
      outdir = value
    when '--force'
      is_force = true
    when '-d'
      dist = value.to_i
  end
end


##########################################
mkdir_with_force(outdir, is_force)
bed_outdir = File.join(outdir, 'bed')
clstr_outdir = File.join(outdir, 'clstr')
syl_outdir = File.join(outdir, 'syl')
mkdir_with_force(bed_outdir, is_force)
mkdir_with_force(clstr_outdir, is_force)
mkdir_with_force(syl_outdir, is_force)

infiles = Dir[indir+'/pseudo*']

infiles.each do |infile|
  parse_pseudo_file(infile, bed_outdir)
end

Dir.foreach(bed_outdir) do |b|
  next if b =~ /^\./
  bed_file = File.join(bed_outdir, b)
  `sort -n -k2 -k3 #{bed_file} | sponge #{bed_file}`
  clstr_outfile = File.join(clstr_outdir, getCorename(bed_file)+'.clstr')
  `bedtools cluster -i #{bed_file} -d #{dist} > #{clstr_outfile}`
end

merge_gene_based_on_clstr(clstr_outdir, syl_outdir)


