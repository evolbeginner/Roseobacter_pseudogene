#! /bin/env ruby


############################
require 'getoptlong'
require 'parallel'

require 'util'
require 'Dir'


############################
seq_indir = nil
db_indir = nil
cpu = 1
nt = 1

cmds = Array.new


############################
opts = GetoptLong.new(
	['--seq_indir', GetoptLong::REQUIRED_ARGUMENT],
	['--db_indir', GetoptLong::REQUIRED_ARGUMENT],
	['--cpu', GetoptLong::REQUIRED_ARGUMENT],
	['--nt', GetoptLong::REQUIRED_ARGUMENT],
)

opts.each do |opt, value|
	case opt
		when '--seq_indir'
			seq_indir = value
    when '--db_indir'
      db_indir = value
    when '--cpu'
      cpu = value.to_i
    when '--nt'
      nt = value.to_i
	end
end


############################
seq_infiles = read_infiles(seq_indir, 'faa')

db_infiles = read_infiles(db_indir, 'ndb').map{|i|File.dirname(i)+'/'+getCorename(i)}.uniq

seq_infiles.each do |seq_infile|
  c = getCorename(seq_infile)
  db_infiles.each do |db_infile|
    db_c = getCorename(db_infile)
    next if db_c == c
    cmds << ['tblastn -query', seq_infile, '-db', db_c, '-outfmt 6 -evalue 1e-15 -out', c+'.vs.'+db_c+'.blast', '-num_threads', nt].join(' ')
  end
end


############################
Parallel.map(cmds, in_processes: cpu) do |cmd|
  puts cmd
  `#{cmd}`
end


